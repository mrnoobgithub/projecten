document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contact-form");
    const submitButton = document.getElementById("SubmitButton");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        const fname = document.getElementById("fname").value;
        const lname = document.getElementById("lname").value;
        const vraag = document.getElementById("vraag").value;


        const data = {
            content: `Nieuwe Vragen:\nVoornaam: ${fname}\nAchternaam: ${lname}\nVraag: ${vraag}`,
        };


        fetch('https://discord.com/api/webhooks/1164101391086780447/F7_XAGe5whTveDE4CAnfQx9inLFRoxT9nZP8mbFKOC5-7bqUNEYIYjKs1fosR0-YL1fy', {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {
                if (response.ok) {
                    alert('Form submitted successfully!');
                    form.reset();
                } else {
                    alert('Form submission failed. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    });
});
